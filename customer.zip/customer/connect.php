<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $conn = mysqli_connect('127.0.0.1:3308', 'root', '', 'gym') or die("Connection Failed: " . mysqli_connect_error());

    // Remove unnecessary isset check here

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $bgroup = $_POST['bgroup'];

    $sql = "INSERT INTO `Customer` (`name`, `email`, `phone`, ) VALUES ('$name', '$email', '$phone')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "successful";
    } else {
        echo "unsuccessful: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
